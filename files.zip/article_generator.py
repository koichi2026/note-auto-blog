"""
記事生成モジュール
Claude APIを使ってnote向けの記事を生成します
"""

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Optional
import anthropic

# 生成した記事の保存先
ARTICLES_DIR = Path("data/articles")


def build_system_prompt() -> str:
    return """あなたはnote向けの高品質な記事を執筆する専門のライターです。

以下のルールを必ず守って記事を生成してください：

【文体・トーン】
- 読者に語りかけるような、親しみやすいが専門性のある文体
- 「です・ます調」で統一
- 専門用語は使うが、必ず分かりやすく説明を加える
- 読者の悩みや疑問に寄り添う視点

【構成】
- タイトル：30〜40文字、読者の興味を引くもの
- リード文：150〜200文字、記事の価値を端的に伝える
- 本文：見出し(##, ###)で構造化、合計1,500〜2,500文字
- まとめ：行動を促す締めくくり
- ハッシュタグ：10個、カテゴリと内容に合ったもの

【note特有の書き方】
- 最初の一文で読者を引き込む
- 小見出しは体言止めか疑問形
- 箇条書きと文章を適切に組み合わせる
- 読者への問いかけを適度に入れる
- 「この記事を読んでわかること」を冒頭に入れる

必ずJSON形式で返答してください。"""


def build_user_prompt(source_title: str, source_summary: str, category: str, source_url: str) -> str:
    category_hint = "技術・IT" if category == "tech" else "ビジネス・マーケティング"

    return f"""以下のニュース記事を参考に、note向けの独自記事を作成してください。

【参考記事】
タイトル: {source_title}
要約: {source_summary}
カテゴリ: {category_hint}
参照元: {source_url}

【重要】参考記事をそのまま要約するのではなく、このニュースを元に読者にとって価値のある独自の視点・解説・考察を加えた記事を書いてください。

以下のJSON形式で返答してください：

{{
  "title": "記事タイトル（30〜40文字）",
  "title_alternatives": ["タイトル案2", "タイトル案3"],
  "lead": "リード文（150〜200文字）",
  "body": "本文（Markdown形式、## と ### で構造化）",
  "summary": "まとめ（200〜300文字）",
  "hashtags": ["ハッシュタグ1", "ハッシュタグ2", "...（10個）"],
  "estimated_read_time": 推定読了時間（分・整数）,
  "category": "{category}"
}}"""


def generate_article(
    source_title: str,
    source_summary: str,
    category: str,
    source_url: str,
    source_name: str
) -> Optional[dict]:
    """
    Claude APIを使って記事を生成する

    Args:
        source_title: 参照元記事のタイトル
        source_summary: 参照元記事の要約
        category: カテゴリ（tech/business）
        source_url: 参照元URL
        source_name: 参照元メディア名

    Returns:
        生成された記事データ（dict）
    """
    client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))

    print(f"✍️ 記事生成中: {source_title[:40]}...")

    try:
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4000,
            system=build_system_prompt(),
            messages=[
                {
                    "role": "user",
                    "content": build_user_prompt(source_title, source_summary, category, source_url)
                }
            ]
        )

        raw_text = response.content[0].text

        # JSON部分を抽出
        if "```json" in raw_text:
            json_str = raw_text.split("```json")[1].split("```")[0].strip()
        elif "```" in raw_text:
            json_str = raw_text.split("```")[1].split("```")[0].strip()
        else:
            json_str = raw_text.strip()

        article_data = json.loads(json_str)

        # メタデータを追加
        article_data["source_title"] = source_title
        article_data["source_url"] = source_url
        article_data["source_name"] = source_name
        article_data["generated_at"] = datetime.now().isoformat()
        article_data["status"] = "draft"  # draft / published

        print(f"✅ 記事生成完了: {article_data.get('title', 'タイトル不明')}")
        return article_data

    except json.JSONDecodeError as e:
        print(f"❌ JSON解析エラー: {e}")
        print(f"レスポンス: {raw_text[:200]}")
        return None
    except Exception as e:
        print(f"❌ 記事生成エラー: {e}")
        return None


def format_for_note(article_data: dict) -> str:
    """
    記事データをnote貼り付け用のテキストにフォーマットする

    Returns:
        note用にフォーマットされたテキスト
    """
    lines = []

    # リード文
    lines.append(article_data.get("lead", ""))
    lines.append("")

    # 本文
    lines.append(article_data.get("body", ""))
    lines.append("")

    # まとめ
    lines.append("## まとめ")
    lines.append("")
    lines.append(article_data.get("summary", ""))
    lines.append("")

    # ハッシュタグ
    hashtags = article_data.get("hashtags", [])
    if hashtags:
        tag_line = " ".join([f"#{tag}" if not tag.startswith("#") else tag for tag in hashtags])
        lines.append(tag_line)

    return "\n".join(lines)


def save_article(article_data: dict) -> Path:
    """記事をJSONファイルとして保存する"""
    ARTICLES_DIR.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = ARTICLES_DIR / f"article_{timestamp}.json"

    with open(filename, "w", encoding="utf-8") as f:
        json.dump(article_data, f, ensure_ascii=False, indent=2)

    print(f"💾 記事保存: {filename}")
    return filename


def load_articles(status_filter: Optional[str] = None) -> list[dict]:
    """保存済み記事を読み込む"""
    if not ARTICLES_DIR.exists():
        return []

    articles = []
    for filepath in sorted(ARTICLES_DIR.glob("article_*.json"), reverse=True):
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
            data["_filepath"] = str(filepath)
            if status_filter is None or data.get("status") == status_filter:
                articles.append(data)

    return articles


def update_article_status(filepath: str, status: str):
    """記事のステータスを更新する"""
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)

    data["status"] = status
    data["updated_at"] = datetime.now().isoformat()

    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    # テスト用
    article = generate_article(
        source_title="生成AIがビジネスを変革：2025年の最新トレンド",
        source_summary="生成AIの活用が急速に進み、多くの企業がビジネスプロセスの自動化に取り組んでいる。",
        category="tech",
        source_url="https://example.com/ai-trends",
        source_name="テストメディア"
    )

    if article:
        print("\n生成されたタイトル:", article.get("title"))
        filepath = save_article(article)
        print("保存先:", filepath)
